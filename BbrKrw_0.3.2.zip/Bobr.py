import re
import sys

# Таблица соответствий Bobr Kurwa → Python
BOBR_TRANSLATIONS = {
    "BobrInput": "input",  # сначала длинные ключи!
    "Bobr": "print",
    "IfBob": "if",
    "ElzKrw": "else",
    "ElifKrw": "elif",
    "LoopBob": "while",
    "4Bob": "for",
    "InnBob": "in",
    "BdefBobr": "def",
    "GivKrw": "return",
    "BportBobr": "import",
    "FrBobr": "from",
    "AzBob": "as",
    "BobTrue": "True",
    "BobLie": "False",
    "NoBob": "None",
    "AndrKrw": "and",
    "OrKrw": "or",
    "NotBobr": "not",
    "LetItBob": "pass",
    "SmashBob": "break",
    "KeepBob": "continue",
    "Bobass": "class",
    "WifBobr": "with",
    "TryBob": "try",
    "OopsBob": "except",
    "FineBob": "finally",
    "Kurwa!": "raise",
    "IzBob": "is",
    "SilentBob": "lambda",

    # Символы
    "Bober": "=",       # присваивание
    "Kurwa": "+",       # сложение
    "Bbr": "(",         # открывающая скобка
    "Bob": ")",         # закрывающая скобка
    "Krw": "\"",        # кавычки
}

def translate_bobr_kurwa(code):
    # Удаляем комментарии
    code = re.sub(r'Kurw.*', '', code)

    # Разделяем команды
    commands = [cmd.strip() for cmd in code.split(';') if cmd.strip()]

    translated = []

    for command in commands:
        translated_command = command
        for bobr_word in sorted(BOBR_TRANSLATIONS, key=len, reverse=True):
            translated_command = translated_command.replace(bobr_word, BOBR_TRANSLATIONS[bobr_word])
        translated.append(translated_command)

    return '\n'.join(translated)

def run_bobr_kurwa(code):
    translated = translate_bobr_kurwa(code)
    print(">> Translated Python code:\n", translated)
    try:
        exec(translated, globals())
    except Exception as e:
        print("[Ошибка во время выполнения]:", e)

if __name__ == "__main__":
    if len(sys.argv) > 1:
        filename = sys.argv[1]
        try:
            with open(filename, "r", encoding="utf-8") as f:
                code = f.read()
            run_bobr_kurwa(code)
        except FileNotFoundError:
            print(f"Файл {filename} потеряли")
    else:
        print("Юзай: python Bobr.py путь_к_файлу.bob")
