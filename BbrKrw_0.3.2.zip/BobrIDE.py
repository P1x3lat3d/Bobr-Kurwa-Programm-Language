import tkinter as tk
from tkinter import ttk, simpledialog

# ===== Языки =====
LANGUAGES = {
    "English": {
        "title": "Bobr Kurwa IDE",
        "code_tab": "Code",
        "settings_tab": "Settings",
        "run_button": "Run Bobr Code",
        "theme": "Theme",
        "language": "Language",
        "light": "Light",
        "dark": "Dark"
    },
    "Русский": {
        "title": "Bobr Kurwa IDE",
        "code_tab": "Код",
        "settings_tab": "Настройки",
        "run_button": "Запустить Бобр-код",
        "theme": "Тема",
        "language": "Язык",
        "light": "Светлая",
        "dark": "Тёмная"
    }
}

# ===== Переводчик Bobr Kurwa =====
BOBR_TRANSLATIONS = {
    "BobrInput": "input", "Bobr": "print", "IfBob": "if", "ElzKrw": "else",
    "ElifKrw": "elif", "LoopBob": "while", "4Bob": "for", "InnBob": "in",
    "BdefBobr": "def", "GivKrw": "return", "BportBobr": "import",
    "FrBobr": "from", "AzBob": "as", "BobTrue": "True", "BobLie": "False",
    "NoBob": "None", "AndrKrw": "and", "OrKrw": "or", "NotBobr": "not",
    "LetItBob": "pass", "SmashBob": "break", "KeepBob": "continue",
    "Bobass": "class", "WifBobr": "with", "TryBob": "try", "OopsBob": "except",
    "FineBob": "finally", "Kurwa!": "raise", "IzBob": "is", "SilentBob": "lambda",
    "Bober": "=", "Kurwa": "+", "Bbr": "(", "Bob": ")", "Krw": "\""
}

def translate_bobr_kurwa(code):
    commands = [cmd.strip() for cmd in code.split(';') if cmd.strip()]
    translated = []
    for command in commands:
        translated_command = command
        for word in sorted(BOBR_TRANSLATIONS, key=len, reverse=True):
            translated_command = translated_command.replace(word, BOBR_TRANSLATIONS[word])
        translated.append(translated_command)
    return '\n'.join(translated)

def run_bobr_code():
    code = editor.get("1.0", tk.END)
    translated_code = translate_bobr_kurwa(code)
    globals()["input"] = lambda prompt="": simpledialog.askstring("Ввод", prompt)
    output_text.delete("1.0", tk.END)
    output_text.insert(tk.END, ">> Translated Python code:\n" + translated_code + "\n\n")
    try:
        exec(translated_code, globals())
    except Exception as e:
        output_text.insert(tk.END, f"[Ошибка]: {e}")

def apply_theme():
    theme = theme_var.get()
    bg = "#1e1e1e" if theme == "dark" else "white"
    fg = "lightgreen" if theme == "dark" else "black"
    editor.config(bg=bg, fg=fg, insertbackground=fg)
    output_text.config(bg=bg, fg=fg, insertbackground=fg)
    code_frame.config(bg=bg)
    settings_frame.config(bg=bg)
    theme_label.config(bg=bg, fg=fg)
    lang_label.config(bg=bg, fg=fg)
    run_button.config(bg=bg, fg=fg)
    root.config(bg=bg)

def apply_language():
    global LABELS
    LABELS = LANGUAGES[lang_var.get()]
    root.title(LABELS["title"])
    notebook.tab(0, text=LABELS["code_tab"])
    notebook.tab(1, text=LABELS["settings_tab"])
    run_button.config(text=LABELS["run_button"])
    theme_label.config(text=LABELS["theme"])
    lang_label.config(text=LABELS["language"])

    # Обновление меток тем
    theme_menu["menu"].entryconfig(0, label=LABELS["light"])
    theme_menu["menu"].entryconfig(1, label=LABELS["dark"])
    apply_theme()

# ===== GUI =====
root = tk.Tk()
lang_var = tk.StringVar(value="English")
theme_var = tk.StringVar(value="light")
LABELS = LANGUAGES["English"]
root.title(LABELS["title"])

notebook = ttk.Notebook(root)
notebook.pack(fill="both", expand=True)

code_frame = tk.Frame(notebook)
notebook.add(code_frame, text=LABELS["code_tab"])

editor = tk.Text(code_frame, wrap="word", height=15)
editor.pack(fill="both", expand=True)

run_button = tk.Button(code_frame, text=LABELS["run_button"], command=run_bobr_code)
run_button.pack()

output_text = tk.Text(code_frame, wrap="word", height=10)
output_text.pack(fill="both", expand=True)

settings_frame = tk.Frame(notebook)
notebook.add(settings_frame, text=LABELS["settings_tab"])

theme_label = tk.Label(settings_frame, text=LABELS["theme"])
theme_label.pack(pady=(10, 0))

theme_menu = ttk.OptionMenu(settings_frame, theme_var, "light", "light", "dark", command=lambda _: apply_theme())
theme_menu.pack()

lang_label = tk.Label(settings_frame, text=LABELS["language"])
lang_label.pack(pady=(10, 0))

lang_menu = ttk.OptionMenu(settings_frame, lang_var, "English", "English", "Русский", command=lambda _: apply_language())
lang_menu.pack()

apply_theme()
root.mainloop()