import tkinter as tk
from tkinter import ttk, simpledialog
import sys

# ====== Переводы ======
LANGUAGES = {
    "English": {
        "title": "Bobr Kurwa IDE",
        "code_tab": "Code",
        "settings_tab": "Settings",
        "run_button": "Run Bobr Code",
        "theme": "Theme",
        "language": "Language",
        "dark": "Dark",
        "light": "Light",
        "error": "[Error]:"
    },
    "Русский": {
        "title": "Среда для Bobr Kurwa",
        "code_tab": "Код",
        "settings_tab": "Настройки",
        "run_button": "Запуск Bobr-кода",
        "theme": "Тема",
        "language": "Язык",
        "dark": "Тёмная",
        "light": "Светлая",
        "error": "[Ошибка]:"
    }
}

# ====== Bobr Kurwa -> Python ======
BOBR_TRANSLATIONS = {
    "BobrInput": "input",
    "Bobr": "print",
    "IfBob": "if",
    "ElzKrw": "else",
    "ElifKrw": "elif",
    "LoopBob": "while",
    "4Bob": "for",
    "InnBob": "in",
    "BdefBobr": "def",
    "GivKrw": "return",
    "BportBobr": "import",
    "FrBobr": "from",
    "AzBob": "as",
    "BobTrue": "True",
    "BobLie": "False",
    "NoBob": "None",
    "AndrKrw": "and",
    "OrKrw": "or",
    "NotBobr": "not",
    "LetItBob": "pass",
    "SmashBob": "break",
    "KeepBob": "continue",
    "Bobass": "class",
    "WifBobr": "with",
    "TryBob": "try",
    "OopsBob": "except",
    "FineBob": "finally",
    "Kurwa!": "raise",
    "IzBob": "is",
    "SilentBob": "lambda",
    "Bober": "=",
    "Kurwa": "+",
    "Bbr": "(",
    "Bob": ")",
    "Krw": "\""
}

def translate_bobr_kurwa(code):
    commands = [cmd.strip() for cmd in code.split(';') if cmd.strip()]
    translated = []
    for command in commands:
        translated_command = command
        for word in sorted(BOBR_TRANSLATIONS, key=len, reverse=True):
            translated_command = translated_command.replace(word, BOBR_TRANSLATIONS[word])
        translated.append(translated_command)
    return '\n'.join(translated)

class Redirector:
    def __init__(self, widget):
        self.widget = widget
    def write(self, text):
        self.widget.insert("end", text)
        self.widget.see("end")
    def flush(self): pass

def run_bobr_code():
    code = editor.get("1.0", tk.END)
    translated_code = translate_bobr_kurwa(code)

    output_text.delete("1.0", tk.END)
    output_text.insert("end", ">> Translated Python code:\n" + translated_code + "\n\n")

    globals()["input"] = lambda prompt="": simpledialog.askstring("Input", prompt)

    sys.stdout = Redirector(output_text)
    sys.stderr = Redirector(output_text)

    try:
        exec(translated_code, globals())
    except Exception as e:
        output_text.insert("end", f"{LABELS['error']} {e}\n")

def apply_theme():
    theme = theme_var.get()
    if theme == LABELS["dark"]:
        colors = {
            "bg": "#1e1e1e",
            "fg": "#d4d4d4",
            "button_bg": "#333333",
            "button_fg": "#ffffff",
            "insert": "#ffffff",
            "output_fg": "#00ff00"
        }
    else:
        colors = {
            "bg": "white",
            "fg": "black",
            "button_bg": "lightgray",
            "button_fg": "black",
            "insert": "black",
            "output_fg": "black"
        }

    editor.config(bg=colors["bg"], fg=colors["fg"], insertbackground=colors["insert"])
    output_text.config(bg=colors["bg"], fg=colors["output_fg"], insertbackground=colors["insert"])
    run_button.config(bg=colors["button_bg"], fg=colors["button_fg"])
    theme_menu.config(bg=colors["button_bg"], fg=colors["button_fg"])
    lang_menu.config(bg=colors["button_bg"], fg=colors["button_fg"])
    theme_label.config(bg=colors["bg"], fg=colors["fg"])
    lang_label.config(bg=colors["bg"], fg=colors["fg"])
    settings_frame.config(bg=colors["bg"])
    code_frame.config(bg=colors["bg"])
    root.config(bg=colors["bg"])

def apply_language():
    global LABELS
    LABELS = LANGUAGES[lang_var.get()]
    root.title(LABELS["title"])
    notebook.tab(0, text=LABELS["code_tab"])
    notebook.tab(1, text=LABELS["settings_tab"])
    run_button.config(text=LABELS["run_button"])
    theme_label.config(text=LABELS["theme"])
    lang_label.config(text=LABELS["language"])
    apply_theme()

# ==== GUI ====
root = tk.Tk()
lang_var = tk.StringVar(value="English")
LABELS = LANGUAGES["English"]
root.title(LABELS["title"])

notebook = ttk.Notebook(root)
notebook.pack(fill="both", expand=True)

# --- Вкладка: Код ---
code_frame = tk.Frame(notebook)
notebook.add(code_frame, text=LABELS["code_tab"])

editor = tk.Text(code_frame, wrap="word", height=15)
editor.pack(fill="both", expand=True)

run_button = tk.Button(code_frame, text=LABELS["run_button"], command=run_bobr_code)
run_button.pack()

output_text = tk.Text(code_frame, wrap="word", height=10)
output_text.pack(fill="both", expand=True)

# --- Вкладка: Настройки ---
settings_frame = tk.Frame(notebook)
notebook.add(settings_frame, text=LABELS["settings_tab"])

theme_label = tk.Label(settings_frame, text=LABELS["theme"])
theme_label.pack()

theme_var = tk.StringVar(value=LABELS["light"])
theme_menu = tk.OptionMenu(settings_frame, theme_var, LABELS["light"], LABELS["dark"], command=lambda _: apply_theme())
theme_menu.pack(pady=5)

lang_label = tk.Label(settings_frame, text=LABELS["language"])
lang_label.pack()

lang_menu = tk.OptionMenu(settings_frame, lang_var, "English", "Русский", command=lambda _: apply_language())
lang_menu.pack(pady=5)

apply_language()
root.mainloop()