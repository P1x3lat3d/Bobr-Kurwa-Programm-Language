import tkinter as tk
from tkinter import scrolledtext
from pygments import lex
from pygments.lexers import PythonLexer
from pygments.styles import get_style_by_name
from pygments.token import Token
import subprocess
import os

def apply_syntax_highlighting(text_widget, code, lexer=PythonLexer(), style_name='monokai'):
    style = get_style_by_name(style_name)
    text_widget.delete('1.0', tk.END)

    for token, content in lex(code, lexer):
        tag_name = str(token)
        text_widget.insert(tk.END, content, tag_name)
        if not text_widget.tag_cget(tag_name, 'foreground'):
            color = style.style_for_token(token).get('color')
            if color:
                text_widget.tag_config(tag_name, foreground=f'#{color}')

def run_bobr_code():
    code = editor.get("1.0", tk.END)
    output.delete("1.0", tk.END)
    apply_syntax_highlighting(editor, code)

    # saving in temporary "temp.bob" file
    temp_bob_file = "temp.bob"
    with open(temp_bob_file, "w", encoding="utf-8") as f:
        f.write(code)

    # Bobr.py Compilator start
    try:
        result = subprocess.run(
            ["python", "Bobr.py", temp_bob_file],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        output.insert(tk.END, result.stdout)
        if result.stderr:
            output.insert(tk.END, "\n[Error]\n" + result.stderr)
    except Exception as e:
        output.insert(tk.END, f"error: {e}")

# Main window
root = tk.Tk()
root.title("Bobr Kurwa IDE")
root.configure(bg="#1e1e1e")
root.geometry("900x600")

# Code input
editor = scrolledtext.ScrolledText(root, wrap=tk.WORD, font=("Consolas", 12),
                                   bg="#1e1e1e", fg="#ffffff", insertbackground='white')
editor.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

# Run
run_button = tk.Button(root, text="Run Bobr Code", command=run_bobr_code,
                       bg="#444", fg="white", font=("Consolas", 12))
run_button.pack(pady=5)

# Code output
output = tk.Text(root, height=10, font=("Consolas", 11), bg="#111", fg="#0f0")
output.pack(fill=tk.X, padx=10, pady=(0,10))

root.mainloop()